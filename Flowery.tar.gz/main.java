/***************************************************
* Author: Francis Lowery
*
*
****************************************************/

public class main
{
  public static void println(Object o)
  {
    System.out.println(o);
  }
  public static void main(String args[])
  {
    dfa x = new dfa();
    x.printDFA();
  }
}
